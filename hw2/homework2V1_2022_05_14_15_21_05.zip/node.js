class Node {
  constructor(label,rank){
    this.label = label
    this.rank  = rank
    this.connectedTo = new Map();
    this.x = 50+  Math.random() *350;
    this.y = 50+ Math.random() *350;
  }
}
