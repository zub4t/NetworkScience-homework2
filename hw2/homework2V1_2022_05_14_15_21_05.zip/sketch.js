let pageRank = new PageRank();
let graph = new Graph((x)=>{pageRank.ranking(0.85,x)} );



let old = undefined;
let converged = false;
const offset = 600 
const epslon = 0.01;
let calcPlot = true
let converged_list = []
let converged_points_list = []
let converged_nodes_list = []
let converged_nodes_points_list = []
let converged_node_color_list =[]
function setup() {
  createCanvas(window.innerWidth, window.innerHeight);
  
  frameRate(1)
}

function draw() {

  background(240);
    
  

  graph.nodes.forEach((node)=>{
     fill("white");
      circle(node.x, node.y, 20);
      fill("red");
      textSize(18);
      text(node.label, node.x, node.y);

     
      node.connectedTo.forEach((neighbor)=>{
      stroke(200)
      line(node.x,  node.y, neighbor.x, neighbor.y);
      stroke(100)
        
      if(graph.convergedR!=undefined){
        fill("black");
        textSize(10);
        text(graph.convergedR[node.label.charCodeAt(0)-65], node.x-10, node.y+20);
      }
      let v0 = createVector( node.x,  node.y);
      let v1 = createVector( neighbor.x, neighbor.y);
     // drawArrow(v0, v1, 'black');
      })
    

    })

 
  if(graph.matrix != undefined){
    if(calcPlot){
      
        for(let i=0;i<=1;i=i+0.05){
          let c = 1
          while(!converged){
             fn(i,epslon)
            c++;
          }
          converged_list.push({"x":i,"y":c})
          converged_node_color_list.push(randomColor())
          converged_nodes_list.push(graph.convergedR)
          graph.restore()
          converged = false
        }
   
      calcPlot= false
      
    }else{
      fn(0.85,epslon)
      drawEllipses()
    }

  }
    fill(0, 0, 0, 0);
    rect(40, 40, 360, 360);
    rect(590,430,500, -400);
    rect(40,810,500, -400);
}

const fn = (beta,epslon)=>{
             if(!converged){
              graph.convergedR = multiply(graph.matrix,graph.r)
              graph.matrix = multiply(graph.matrix,graph.matrix)   
              scaleBy(graph.matrix,beta)
              sumBy(graph.r, (1-beta) / graph.nodes.size)

              if( old!=undefined && Math.abs(sumArray(old) - sumArray(graph.convergedR)) <epslon ){
              //  console.log(old)
              //  console.log(graph.r)
               // console.log( sumArray(old) +":"+ sumArray(graph.convergedR)+"--")
                converged=true
                //alert("converged!!! It took "+frameCount+" interactions")

              }
              old = graph.convergedR              
            }
             
}

function drawEllipses(){
  //fst graph
  for(let i =0; i < converged_list.length; i++){
    let x = offset + (i * (400 / (converged_list.length-1)));
    let y = 500+(converged_list[i].y * -20)  ;
     fill("red")
    ellipse(x, y, 7);
    converged_points_list.push({"x":x,"y":y})
  }
  for(let i =0; i < converged_points_list.length-1; i++){
    if(converged_points_list[i].x -converged_points_list[i+1].x < 0){
       line(converged_points_list[i].x,
           converged_points_list[i].y, 
           converged_points_list[i+1].x,
           converged_points_list[i+1].y);

    }
  }
   /*
  //snd graph
//console.table(converged_nodes_list)
  for(let i =0; i < converged_nodes_list.length; i++){
   fill(converged_node_color_list[i])
    let aux = [];
     for(let j =0; j < converged_nodes_list[0].length; j++){
        let x = 40+ (i * (400 / (converged_nodes_list.length-1)));
        let y = 700+( Math.log10(converged_nodes_list[i][j]) )  ;
    //   console.log("("+i+","+ Math.log10(converged_nodes_list[i][j])+")")
      aux.push({"x":x,"y":y})
    
        ellipse(x, y, 5);
     }
    converged_nodes_points_list.push(aux)
  }
    */
    
}

function randomColor() { 
  
  r = random(255); 
  g = random(100,200); 
  b = random(100); 
  a = random(200,255); 
  return color(r, g, b, a);
 
}


